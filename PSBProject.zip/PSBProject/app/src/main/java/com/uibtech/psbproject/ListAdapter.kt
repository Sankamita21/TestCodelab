package com.uibtech.psbproject

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class ListAdapter(
        private val arrayList: List<DataModel>,
        var context: Context) : RecyclerView.Adapter<ListAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.list_items, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val dataModel = arrayList[position]
        try {
            val albm = dataModel.albm.replace("http", "https")

            if(dataModel.title.contains("null"))
            {
                holder.title.text = ""
            }

            else
            {
                holder.title.text = dataModel.title
            }

            if(dataModel.dscr.contains("null"))
            {
                holder.descrip.text = ""
            }

            else
            {
                holder.descrip.text = dataModel.dscr
            }
            Picasso.get().load(albm).error(R.drawable.no_img_avl).into(holder.imageView)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    class ViewHolder internal constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.title)
        val descrip: TextView = itemView.findViewById(R.id.des)
        var imageView: ImageView = itemView.findViewById(R.id.imageView)

    }

    init {
        notifyDataSetChanged()
    }
}